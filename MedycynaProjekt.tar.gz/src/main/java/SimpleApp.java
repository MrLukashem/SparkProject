/* SimpleApp.java */
import org.apache.spark.api.java.*;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.*;
import java.util.List;

import java.util.Arrays;

public class SimpleApp {

  public static void main(String[] args) {
    SparkConf conf = new SparkConf().setAppName("Simple Application");
    JavaSparkContext sc = new JavaSparkContext(conf);
    
    List<String> data = Arrays.asList("hi", "fucking", "mother", "fucker", "mrruuu");
    JavaRDD<String> rdd = sc.parallelize(data);
    JavaRDD<String> pipe = rdd.pipe("/home/mrlukashem/bin/spark/MedycynaProjekt/sample.sh");
    pipe
    .foreach( new VoidFunction<String>(){ 
          public void call(String line) {
              System.out.println(line); //this is dummy function call 
    }});

   // List<Integer> data = Arrays.asList(1, 2, 3, 4, 5, 6, 10);
  //  JavaRDD<Integer> parallvalues = sc.parallelize(data);

 //   Integer result = parallvalues.reduce(new Function2<Integer, Integer, Integer>() {
//  public Integer call(Integer a, Integer b) { return a + b; }
//});

  //  System.out.println("wynik to = " + result);
  }
}
